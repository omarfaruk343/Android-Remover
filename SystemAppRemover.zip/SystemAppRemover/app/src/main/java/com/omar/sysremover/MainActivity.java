package com.omar.sysremover;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * সিস্টেম অ্যাপ রিমুভার।
 * রুট (su) থাকলে সরাসরি রিমুভ করে। রুট না থাকলে ADB কমান্ড তৈরি করে দেয়।
 * রিমুভ মানে বর্তমান ইউজারের জন্য আনইনস্টল (pm uninstall -k --user 0) - রিস্টোর করা যায়।
 */
public class MainActivity extends Activity {

    private static final String PREFS = "removed";
    private static final String KEY_REMOVED = "pkgs";
    private static final Pattern PKG = Pattern.compile("^[a-zA-Z0-9_.]+$");

    // এগুলো সরালে ফোন বুট/কাজ করা বন্ধ হতে পারে - তাই ব্লক করা
    private static final String[] CRITICAL = {
            "android", "com.android.systemui", "com.android.phone", "com.android.settings",
            "com.android.providers.", "com.android.server.telecom", "com.android.shell",
            "com.android.packageinstaller", "com.google.android.packageinstaller",
            "com.android.permissioncontroller", "com.google.android.permissioncontroller",
            "com.android.inputmethod", "com.android.bluetooth", "com.android.nfc",
            "com.android.networkstack", "com.android.cellbroadcast", "com.android.location",
            "com.android.vending", "com.google.android.gms", "com.google.android.gsf",
            "com.android.keychain", "com.android.certinstaller", "com.android.wifi",
            "com.android.se", "com.android.stk", "com.android.mms.service",
            "com.android.emergency", "com.android.captiveportallogin", "com.android.webview",
            "com.google.android.webview", "com.android.ext.services", "com.android.managedprovisioning",
            "com.android.internal.", "com.android.launcher", "com.android.settings.intelligence",
            "com.android.carrierconfig", "com.android.companiondevicemanager",
            "com.android.launcher3", "com.sec.android.app.launcher", "com.miui.home", "com.android.dynsystem", "com.android.modulemetadata", "com.android.documentsui",
            "com.android.storagemanager", "com.android.externalstorage"
    };

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Item> all = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private AppAdapter adapter;
    private CheckBox cbSystemOnly;
    private EditText search;
    private TextView counter;
    private SharedPreferences prefs;

    static class Item {
        String label, pkg;
        android.graphics.drawable.Drawable icon;
        boolean system, critical, checked;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        loadApps();
    }

    // ---------------------------------------------------------------- UI
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        search = new EditText(this);
        search.setHint("অ্যাপ খুঁজুন…");
        search.setSingleLine(true);
        search.setPadding(dp(16), dp(12), dp(16), dp(12));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { applyFilter(); }
        });
        root.addView(search, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), 0, dp(12), 0);
        cbSystemOnly = new CheckBox(this);
        cbSystemOnly.setText("শুধু সিস্টেম অ্যাপ");
        cbSystemOnly.setChecked(true);
        cbSystemOnly.setOnCheckedChangeListener((v, c) -> applyFilter());
        row.addView(cbSystemOnly, new LinearLayout.LayoutParams(0, -2, 1));
        counter = new TextView(this);
        counter.setTextColor(Color.DKGRAY);
        row.addView(counter);
        root.addView(row, new LinearLayout.LayoutParams(-1, -2));

        ListView lv = new ListView(this);
        adapter = new AppAdapter();
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((p, v, pos, id) -> {
            Item it = shown.get(pos);
            if (it.critical) {
                Toast.makeText(this, "এই অ্যাপ সরানো নিরাপদ নয়, তাই ব্লক করা আছে", Toast.LENGTH_SHORT).show();
                return;
            }
            it.checked = !it.checked;
            adapter.notifyDataSetChanged();
            updateCounter();
        });
        lv.setOnItemLongClickListener((p, v, pos, id) -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + shown.get(pos).pkg));
            startActivity(i);
            return true;
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(8), dp(4), dp(8), dp(8));
        Button rm = new Button(this);
        rm.setText("রিমুভ করুন");
        rm.setOnClickListener(v -> confirmRemove());
        Button rs = new Button(this);
        rs.setText("রিস্টোর");
        rs.setOnClickListener(v -> showRestore());
        Button hp = new Button(this);
        hp.setText("সাহায্য");
        hp.setOnClickListener(v -> showHelp());
        bar.addView(rm, new LinearLayout.LayoutParams(0, -2, 2));
        bar.addView(rs, new LinearLayout.LayoutParams(0, -2, 1.3f));
        bar.addView(hp, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private void updateCounter() {
        int n = 0;
        for (Item i : all) if (i.checked) n++;
        counter.setText("নির্বাচিত: " + n);
    }

    private void applyFilter() {
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean sysOnly = cbSystemOnly.isChecked();
        shown.clear();
        for (Item i : all) {
            if (sysOnly && !i.system) continue;
            if (!q.isEmpty() && !i.label.toLowerCase(Locale.ROOT).contains(q)
                    && !i.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            shown.add(i);
        }
        adapter.notifyDataSetChanged();
        updateCounter();
    }

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            List<Item> tmp = new ArrayList<>();
            for (ApplicationInfo a : apps) {
                if (a.packageName.equals(getPackageName())) continue;
                Item it = new Item();
                it.pkg = a.packageName;
                it.label = String.valueOf(pm.getApplicationLabel(a));
                it.icon = pm.getApplicationIcon(a);
                it.system = (a.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
                it.critical = isCritical(a.packageName);
                tmp.add(it);
            }
            Collections.sort(tmp, new Comparator<Item>() {
                public int compare(Item x, Item y) {
                    return x.label.compareToIgnoreCase(y.label);
                }
            });
            ui.post(() -> {
                all.clear();
                all.addAll(tmp);
                applyFilter();
            });
        }).start();
    }

    private static boolean isCritical(String pkg) {
        for (String c : CRITICAL) {
            if (c.endsWith(".") ? pkg.startsWith(c) : pkg.equals(c) || pkg.startsWith(c + ".")) return true;
        }
        return false;
    }

    class AppAdapter extends BaseAdapter {
        public int getCount() { return shown.size(); }
        public Object getItem(int i) { return shown.get(i); }
        public long getItemId(int i) { return i; }

        public View getView(int pos, View cv, ViewGroup parent) {
            LinearLayout row;
            ImageView iv;
            TextView t1, t2;
            CheckBox cb;
            if (cv == null) {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(8), dp(12), dp(8));
                iv = new ImageView(MainActivity.this);
                row.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setPadding(dp(12), 0, dp(8), 0);
                t1 = new TextView(MainActivity.this);
                t1.setTextSize(16);
                t1.setTypeface(Typeface.DEFAULT_BOLD);
                t1.setTextColor(Color.BLACK);
                t2 = new TextView(MainActivity.this);
                t2.setTextSize(12);
                t2.setTextColor(Color.GRAY);
                col.addView(t1);
                col.addView(t2);
                row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
                cb = new CheckBox(MainActivity.this);
                cb.setClickable(false);
                cb.setFocusable(false);
                row.addView(cb);
                row.setTag(new Object[]{iv, t1, t2, cb});
            } else {
                row = (LinearLayout) cv;
            }
            Object[] h = (Object[]) row.getTag();
            iv = (ImageView) h[0]; t1 = (TextView) h[1]; t2 = (TextView) h[2]; cb = (CheckBox) h[3];
            Item it = shown.get(pos);
            iv.setImageDrawable(it.icon);
            t1.setText(it.label);
            t2.setText(it.critical ? "🔒 সুরক্ষিত - " + it.pkg : it.pkg);
            cb.setChecked(it.checked);
            cb.setEnabled(!it.critical);
            row.setAlpha(it.critical ? 0.45f : 1f);
            return row;
        }
    }

    // ---------------------------------------------------------------- রিমুভ
    private List<String> selected() {
        List<String> l = new ArrayList<>();
        for (Item i : all) if (i.checked && !i.critical && PKG.matcher(i.pkg).matches()) l.add(i.pkg);
        return l;
    }

    private void confirmRemove() {
        final List<String> sel = selected();
        if (sel.isEmpty()) {
            Toast.makeText(this, "আগে অ্যাপ নির্বাচন করুন", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(sel.size() + "টি অ্যাপ রিমুভ করবেন?")
                .setMessage("অ্যাপগুলো বর্তমান ইউজার থেকে সরানো হবে। পরে 'রিস্টোর' থেকে ফিরিয়ে আনা যাবে।\n\n"
                        + "সতর্কতা: ভুল অ্যাপ সরালে কিছু ফিচার কাজ নাও করতে পারে। আগে ব্যাকআপ রাখুন।")
                .setPositiveButton("হ্যাঁ, রিমুভ", (d, w) -> runRemove(sel))
                .setNeutralButton("ADB কমান্ড", (d, w) -> showAdb(sel, false))
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void runRemove(final List<String> sel) {
        new Thread(() -> {
            if (!hasRoot()) {
                ui.post(() -> {
                    Toast.makeText(this, "রুট পাওয়া যায়নি - ADB কমান্ড দেখানো হচ্ছে", Toast.LENGTH_LONG).show();
                    showAdb(sel, false);
                });
                return;
            }
            final List<String> ok = new ArrayList<>(), fail = new ArrayList<>();
            Set<String> removed = new HashSet<>(prefs.getStringSet(KEY_REMOVED, new HashSet<String>()));
            for (String p : sel) {
                String out = su("pm uninstall -k --user 0 " + p);
                if (out.contains("Success")) {
                    ok.add(p);
                    removed.add(p);
                } else fail.add(p);
            }
            prefs.edit().putStringSet(KEY_REMOVED, removed).apply();
            ui.post(() -> {
                new AlertDialog.Builder(this)
                        .setTitle("ফলাফল")
                        .setMessage("সফল: " + ok.size() + "\nব্যর্থ: " + fail.size()
                                + (fail.isEmpty() ? "" : "\n\nব্যর্থ:\n" + join(fail, "\n")))
                        .setPositiveButton("ঠিক আছে", null)
                        .show();
                for (Item i : all) i.checked = false;
                loadApps();
            });
        }).start();
    }

    // ---------------------------------------------------------------- রিস্টোর
    private void showRestore() {
        final List<String> removed = new ArrayList<>(prefs.getStringSet(KEY_REMOVED, new HashSet<String>()));
        Collections.sort(removed);
        if (removed.isEmpty()) {
            Toast.makeText(this, "এই অ্যাপ দিয়ে কোনো অ্যাপ রিমুভ করা হয়নি", Toast.LENGTH_LONG).show();
            return;
        }
        final boolean[] chk = new boolean[removed.size()];
        new AlertDialog.Builder(this)
                .setTitle("কোনগুলো ফিরিয়ে আনবেন?")
                .setMultiChoiceItems(removed.toArray(new String[0]), chk, (d, i, c) -> chk[i] = c)
                .setPositiveButton("রিস্টোর", (d, w) -> {
                    final List<String> sel = new ArrayList<>();
                    for (int i = 0; i < chk.length; i++) if (chk[i]) sel.add(removed.get(i));
                    if (sel.isEmpty()) return;
                    new Thread(() -> {
                        if (!hasRoot()) {
                            ui.post(() -> showAdb(sel, true));
                            return;
                        }
                        Set<String> left = new HashSet<>(prefs.getStringSet(KEY_REMOVED, new HashSet<String>()));
                        int n = 0;
                        for (String p : sel) {
                            if (!PKG.matcher(p).matches()) continue;
                            String out = su("cmd package install-existing " + p);
                            if (out.contains("installed")) { left.remove(p); n++; }
                        }
                        prefs.edit().putStringSet(KEY_REMOVED, left).apply();
                        final int count = n;
                        ui.post(() -> {
                            Toast.makeText(this, count + "টি অ্যাপ ফিরে এসেছে", Toast.LENGTH_LONG).show();
                            loadApps();
                        });
                    }).start();
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    // ---------------------------------------------------------------- ADB
    private void showAdb(List<String> pkgs, boolean restore) {
        StringBuilder sb = new StringBuilder();
        for (String p : pkgs) {
            if (!PKG.matcher(p).matches()) continue;
            sb.append(restore ? "adb shell cmd package install-existing " + p
                              : "adb shell pm uninstall -k --user 0 " + p).append('\n');
        }
        final String cmds = sb.toString();
        TextView tv = new TextView(this);
        tv.setPadding(dp(20), dp(12), dp(20), dp(12));
        tv.setTextIsSelectable(true);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(12);
        tv.setText("রুট ছাড়া কম্পিউটারে ADB দিয়ে এই কমান্ডগুলো চালান:\n\n" + cmds);
        new AlertDialog.Builder(this)
                .setTitle("ADB কমান্ড")
                .setView(tv)
                .setPositiveButton("কপি", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("adb", cmds));
                    Toast.makeText(this, "কপি হয়েছে", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
                .setTitle("সাহায্য")
                .setMessage("• অ্যাপে ট্যাপ করে নির্বাচন করুন; দীর্ঘক্ষণ চাপলে অ্যাপের সেটিংস খুলবে।\n"
                        + "• 🔒 চিহ্নিত অ্যাপ ফোনের জন্য জরুরি, তাই সরানো যায় না।\n"
                        + "• রুট থাকলে অ্যাপ সরাসরি রিমুভ করবে।\n"
                        + "• রুট না থাকলে ADB কমান্ড তৈরি করে দেবে (USB debugging চালু করে কম্পিউটার থেকে চালাতে হবে)।\n"
                        + "• রিমুভ মানে ইউজার ০ থেকে আনইনস্টল; সিস্টেম পার্টিশন থেকে ফাইল মোছে না। রিস্টোর করা যায়, আর ফ্যাক্টরি রিসেট দিলেও সব ফিরে আসে।\n"
                        + "• সরানোর আগে গুরুত্বপূর্ণ ডেটার ব্যাকআপ রাখুন।")
                .setPositiveButton("ঠিক আছে", null)
                .show();
    }

    // ---------------------------------------------------------------- শেল
    private boolean hasRoot() {
        return su("id").contains("uid=0");
    }

    private String su(String cmd) {
        StringBuilder out = new StringBuilder();
        Process p = null;
        try {
            p = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(p.getOutputStream());
            os.writeBytes(cmd + "\nexit\n");
            os.flush();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) out.append(line).append('\n');
            p.waitFor();
        } catch (Exception e) {
            return "";
        } finally {
            if (p != null) p.destroy();
        }
        return out.toString();
    }

    private static String join(List<String> l, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(l.get(i));
        }
        return sb.toString();
    }
}
